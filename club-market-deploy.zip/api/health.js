module.exports=(req,res)=>{const e=process.env;res.json({ok:true,time:Date.now(),kusha:!!e.KUSHA_AUTH_TOKEN,otpSecret:!!e.OTP_SECRET})};
