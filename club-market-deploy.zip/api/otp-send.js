const c=require('crypto');
module.exports=async(req,res)=>{
 if(req.method!=='POST')return res.status(405).json({ok:false});
 const T=process.env.KUSHA_AUTH_TOKEN,K=process.env.OTP_SECRET;
 if(!T||!K)return res.status(500).json({ok:false,error:'server_not_configured'});
 const phone=String((req.body||{}).phone||'');
 if(!/^9[78]\d{8}$/.test(phone))return res.status(400).json({ok:false,error:'bad_phone'});
 const code=String(c.randomInt(100000,1000000)),exp=Date.now()+3e5,sig=c.createHmac('sha256',K).update(phone+'.'+code+'.'+exp).digest('hex');
 const r=await fetch('https://kushasms.com/sms/v4/send-user',{method:'POST',headers:{'auth-token':T,'Content-Type':'application/json'},body:JSON.stringify({to:[phone],text:['Club Market OTP: '+code+'. Valid for 5 minutes. Do not share it.']})}).catch(()=>null);
 const j=r?await r.json().catch(()=>null):null,good=r&&r.ok&&j&&j.responses&&j.responses[0]&&!j.responses[0].error;
 if(!good)return res.status(502).json({ok:false,error:'sms_failed'});
 res.json({ok:true,token:exp+'.'+sig});
};
