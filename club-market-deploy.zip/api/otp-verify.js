const c=require('crypto');
module.exports=(req,res)=>{
 const K=process.env.OTP_SECRET,b=req.body||{},[exp,sig]=String(b.token||'').split('.');
 if(!K||req.method!=='POST')return res.status(400).json({ok:false});
 if(Date.now()>+exp)return res.json({ok:false,error:'expired'});
 const want=c.createHmac('sha256',K).update(String(b.phone)+'.'+String(b.code)+'.'+exp).digest('hex');
 const ok=!!sig&&sig.length===want.length&&c.timingSafeEqual(Buffer.from(sig),Buffer.from(want));
 res.json(ok?{ok:true}:{ok:false,error:'invalid'});
};
