-- Run once in Supabase > SQL Editor. Creates a public bucket for club logos (images only, max 256 KB).
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('club-logos','club-logos',true,262144,array['image/webp','image/png','image/jpeg'])
on conflict (id) do nothing;
-- Lets the browser (anon key) upload logos. Before a public launch, move uploads behind an admin-only API.
create policy "club logo upload" on storage.objects for insert to anon with check (bucket_id='club-logos');
