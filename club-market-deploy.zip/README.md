# Club Market: deploy guide

## 0. Security first
- The Kusha token was pasted in a chat: **rotate it in your Kusha dashboard**, then use the new one below.
- `config.js` holds only PUBLIC keys (Firebase web config, VAPID public key, Supabase URL and anon key). Secrets live in Vercel env vars.
- Supabase: keep Row Level Security ON for every table you add.

## 1. GitHub
```
unzip club-market-deploy.zip -d club-market && cd club-market
git init && git add . && git commit -m "Club Market"
git branch -M main && git remote add origin https://github.com/<you>/club-market.git && git push -u origin main
```

## 2. Vercel
1. vercel.com > Add New > Project > import the repo. Framework preset: **Other**. No build command, no output directory.
2. Settings > Environment Variables (Production): `KUSHA_AUTH_TOKEN` = your Kusha token, `OTP_SECRET` = long random string (`openssl rand -hex 32`).
3. Deploy. Open `https://<your-app>.vercel.app/api/health` and check `kusha` and `otpSecret` are `true`.
4. Log in as admin > Profile > **System health checker** and press Run checks.

## 3. Supabase
Run `supabase/storage.sql` in the SQL editor. Club logos then upload to the `club-logos` bucket (falls back to in-app storage if upload fails).

## 4. Firebase push
Cloud Messaging > Web Push certificates already has your VAPID key. Users tap Profile > **Enable push notifications**. Sending pushes from the server needs a Firebase service-account key stored as a Vercel env var; that sender is not included yet.

## 5. Median (website to Android/iOS app)
1. median.co > New app > paste your Vercel URL.
2. Upload `icon-512.png`, set name "Club Market", theme colour `#246CB4`, turn on status bar and pull-to-refresh.
3. Configure push in Median's own Push Notifications settings (web FCM tokens do not work inside a WebView).
4. Build the Android APK/AAB (iOS needs an Apple Developer account) and test on a phone.

## 6. Known limits
- Game data is stored per browser. For one shared market for all friends you still need the Supabase database, RLS and RPC step.
- OTP codes are signed statelessly. Add rate limiting (e.g. Upstash) before a public launch.
- Demo accounts (`user` / 1234, the admin) are inside the app: change them before sharing.
